# Das Leselabor: Die drei Geheimnisse des Waldes

Eine spielerische Web-App zur digitalen Leseförderung in der 3. Schulstufe.

## Sofort ausprobieren

1. `index.html` herunterladen.
2. Die Datei doppelt anklicken. Sie öffnet sich im Webbrowser.
3. Auf **Forschung starten** klicken und alle drei Stationen spielen.

Es ist keine Installation, Anmeldung oder Internetverbindung erforderlich. Die Anwendung verwendet ausschließlich HTML, CSS und JavaScript in **einer** Datei.

## Online veröffentlichen mit GitHub Pages

1. Auf github.com anmelden und ein öffentliches Repository erstellen, zum Beispiel `leselabor`.
2. Die Datei `index.html` in das Repository hochladen und speichern (committen).
3. Im Repository **Settings → Pages** öffnen.
4. Unter **Build and deployment** die Option **Deploy from a branch** wählen.
5. Branch `main` und Ordner `/ (root)` wählen und speichern.
6. Die Adresse erscheint im Pages-Bereich, normalerweise `https://BENUTZERNAME.github.io/leselabor/`. Den tatsächlichen Link dort ablesen und auf einem zweiten Gerät testen.

Alternativ kann die `index.html` bei einem statischen Hostingdienst wie Netlify veröffentlicht werden.

## Inhalt

- Station 1: Igel, drei Fragen zum gezielten Finden von Informationen.
- Station 2: Eichhörnchen, zwei Aufgaben mit anklickbaren Textstellen und eine Wissensfrage.
- Station 3: Fuchs, zwei Fragen und ein Vergleich der drei Tiertexte.
- Gestuftes Hilfesystem mit jeweils drei Tipps.
- Fortschritt, drei Forschungsabzeichen und druckbares Diplom.
- Nutzung auf Tablet und Computer, Tastaturbedienung, kein Zeitdruck.

## Datenschutz und Technik

Die App verwendet keine Cookies, keine externen Bibliotheken, kein Tracking, keine Benutzerkonten und keinen Server für Eingaben. Nur der Spielfortschritt wird lokal in `sessionStorage` für die aktuelle Browser-Sitzung gespeichert. Durch Schließen der Sitzung wird dieser in der Regel gelöscht.

## Im Seminar

Zielgruppe: 3. Schulstufe. Kompetenz: Informationen aus Sachtexten entnehmen, Textbelege finden, Informationen vergleichen. Einsatz in Einzelarbeit oder Partnerarbeit, Dauer ungefähr 15 bis 20 Minuten.

## Hinweise

Die App wurde als Unterrichtsprototyp entwickelt. Vor dem realen Einsatz mit Kindern sollten Aufgaben und Schwierigkeitsgrad mit der Lehrperson geprüft sowie das Spiel mit einigen Testpersonen ausprobiert werden. Die Recherche und der Test *anderer* digitaler Lesefördertools sowie das AA5-Konzeptpapier bleiben eigene Bestandteile der Seminaraufgabe.

## Quellen für die Tierfakten

- DIE UMWELTBERATUNG, Igel: https://www.umweltberatung.at/igel
- Deutsche Wildtier Stiftung, Eichhörnchen: https://www.deutschewildtierstiftung.de/wildtiere/eichhoernchen
- Deutsche Wildtier Stiftung, Rotfuchs: https://www.deutschewildtierstiftung.de/wildtiere/fuchs

Sachtexte und Aufgaben sind für die Anwendung eigenständig formuliert. Die Entwicklung erfolgte mit Unterstützung von ChatGPT.
